# dsc.py

import sys
import datetime
import random
import time
import yaml
import base58
import threading
import hashlib


class Blockchain:
    def __init__(self):
        self.blocks = []
        self.last_empty_block_hash = None

    def add_block(self, hash):
        self.blocks.append(hash)
        self.last_empty_block_hash = hash

    def get_last_block_hash(self):
        if self.last_empty_block_hash:
            return self.last_empty_block_hash
        else:
            return None

    def process_block_request(self, validator_fingerprint, block_number):
        if block_number <= len(self.blocks):
            block_hash = self.blocks[block_number - 1]
            log_message(f"Block request from validator {validator_fingerprint}, Block {block_number} hash {block_hash}")
        else:
            log_message(f"Block request from validator {validator_fingerprint}, Block {block_number} not found")

    def process_balance_request(self, address):
        log_message(f"Balance request for {address}, 0.0 coins")

    def process_transaction_request(self, validator_fingerprint, transaction_id):
        log_message(f"Transaction request status for {transaction_id}, unknown")

    def process_transactions_request(self, address):
        log_message(f"Transactions request for {address}, none found")

# Update the Metronome class to use the new Blockchain class


class Pool:
    def __init__(self):
        self.transactions = []

    def add_transaction(self, transaction_id, sender_address):
        self.transactions.append((transaction_id, sender_address))
        log_message(f"Transaction id {transaction_id} received from {sender_address}, ACK")

    def check_transaction_status(self, transaction_id):
        for _ in range(3):
            time.sleep(1)
            log_message(f"Transaction id {transaction_id} status [unknown]")
            log_message(f"Transaction id {transaction_id} status [submitted]")

    def get_transactions_for_address(self, address):
        log_message(f"Transactions for {address}, none found")

    def start_pool(self, num_threads):
        log_message("Pool started with {} worker threads".format(num_threads))
        threads = []
        for _ in range(num_threads):
            thread = threading.Thread(target=self.process_transactions)
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

    def process_transactions(self):
        while True:
            if self.transactions:
                transaction_id, sender_address = self.transactions.pop(0)
                self.check_transaction_status(transaction_id)
                self.get_transactions_for_address(sender_address)
class Metronome:
    def __init__(self, blockchain):
        self.blockchain = blockchain

    def start_metronome(self, num_threads):
        log_message(f"Metronome started with {num_threads} worker threads")
        threads = []
        for _ in range(num_threads):
            thread = threading.Thread(target=self.create_empty_block)
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

    def create_empty_block(self):
        while True:
            time.sleep(6)  # Create an empty block every 6 seconds
            empty_block_hash = base58.b58encode(bytes(str(random.getrandbits(256)), 'utf-8')).decode('utf-8')
            log_message(f"New block created, hash {empty_block_hash}, sent to blockchain")
            self.blockchain.add_block(empty_block_hash)

class DSCWallet:
    def __init__(self):
        self.public_key = None
        self.private_key = None
        self.balance = 1024.0  # Initial balance for demonstration purposes
        self.current_block = 5  # Initial block for demonstration purposes
        self.pool = Pool()  # Instance of the Pool class
    def create_wallet(self):
        if self.public_key is None and self.private_key is None:
            self.public_key = base58.b58encode(bytes(str(random.getrandbits(256)), 'utf-8')).decode('utf-8')
            self.private_key = base58.b58encode(bytes(str(random.getrandbits(256)), 'utf-8')).decode('utf-8')

            # Change from Blake2b to SHA-256
            hash_function = hashlib.sha256

            # Hashing the public key
            public_key_hash = hash_function(self.public_key.encode('utf-8')).hexdigest()
            self.public_key = base58.b58encode(bytes(public_key_hash, 'utf-8')).decode('utf-8')

            # Hashing the private key
            private_key_hash = hash_function(self.private_key.encode('utf-8')).hexdigest()
            self.private_key = base58.b58encode(bytes(private_key_hash, 'utf-8')).decode('utf-8')

            current_time = datetime.datetime.now().strftime('%Y%m%d %H:%M:%S.%f')[:-3]
            print(f"{current_time} DSC v1.0")
            print(f"{current_time} DSC Public Address: {self.public_key}")
            print(f"{current_time} DSC Private Address: {self.private_key}")

            # Save keys to YAML files
            with open('dsc-config.yaml', 'w') as config_file:
                yaml.dump({'public_key': self.public_key}, config_file)

            with open('dsc-key.yaml', 'w') as key_file:
                yaml.dump({'private_key': self.private_key}, key_file)

            print(f"{current_time} Saved public key to dsc-config.yaml and private key to dsc-key.yaml in local folder")
        else:
            print("Wallet already exists at dsc-key.yaml, wallet create aborted")
    def read_key(self):
        if self.public_key is not None and self.private_key is not None:
            current_time = datetime.datetime.now().strftime('%Y%m%d %H:%M:%S.%f')[:-3]
            print(f"{current_time} DSC v1.0")
            print(f"{current_time} Reading dsc-config.yaml and dsc-key.yaml...")
            print(f"{current_time} DSC Public Address: {self.public_key}")
            print(f"{current_time} DSC Private Address: {self.private_key}")
        else:
            print(
                f"Error in finding key information, ensure that dsc-config.yaml and dsckey.yaml exist and that they contain the correct information. You may need to run “./dsc wallet create.")

    def get_balance(self):
        # Contact the blockchain server to get the balance
        balance_query = f"GET_BALANCE:{self.public_key}"
        balance_response = self.query_balance_server(balance_query)

        current_time = datetime.datetime.now().strftime('%Y%m%d %H:%M:%S.%f')[:-3]
        print(f"{current_time} DSC v1.0")
        print(f"{current_time} DSC Wallet balance: {balance_response} coins at block 5") #need to extract blocknumber from the blockchain and print here

    def query_balance_server(self, query):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as balance_socket:
                balance_socket.connect(('localhost', 10007))  # Use the port number for your balance server
                balance_socket.sendall(query.encode('utf-8'))
                response = balance_socket.recv(1024).decode('utf-8')
                return float(response)
        except Exception as e:
            print(f"Error connecting to the balance server: {e}")
            return 0.0

    def send_coins(self, amount, destination_address):
        current_time = datetime.datetime.now().strftime('%Y%m%d %H:%M:%S.%f')[:-3]
        print(f"{current_time} DSC v1.0")
        print(f"{current_time} DSC Wallet balance: {self.balance} coins at block {self.current_block}")

        # Create a transaction ID
        transaction_id = ''.join(random.choices('0123456789abcdef', k=16))
        print(f"{current_time} Created transaction {transaction_id}, Sending {amount} coins to {destination_address}")

        # Submit the transaction to the pool
        self.pool.add_transaction(transaction_id, self.public_key)
        print(f"{current_time} Transaction {transaction_id} submitted to pool")

        # Check the status of the transaction
        for _ in range(5):
            time.sleep(1)
            status = self.pool.check_transaction_status(transaction_id)
            print(f"{current_time} Transaction {transaction_id} status [{status}]")

            if status == "unconfirmed":
                time.sleep(1)
                print(f"{current_time} Transaction {transaction_id} status [confirmed], block {self.current_block + 1} index 3 in 5.179 seconds")
                self.balance -= float(amount)
                print(f"{current_time} DSC Wallet balance: {self.balance} coins at block {self.current_block + 1}")
                return

    def check_transaction_status(self, transaction_id):
        current_time = datetime.datetime.now().strftime('%Y%m%d %H:%M:%S.%f')[:-3]
        print(f"{current_time} DSC v1.0")

        # Simulating fetching transaction status from the pool server
        pool_response = self.fetch_transaction_status_from_pool(transaction_id)

        if pool_response == "confirmed":
            print(f"{current_time} Transaction {transaction_id} status [confirmed]")
        elif pool_response == "unconfirmed":
            print(f"{current_time} Transaction {transaction_id} status [unconfirmed]")
        else:
            print(f"{current_time} Transaction {transaction_id} status [unknown]")

    def get_all_transactions(self):
        current_time = datetime.datetime.now().strftime('%Y%m%d %H:%M:%S.%f')[:-3]
        print(f"{current_time} DSC v1.0")

        # Retrieve the dynamically generated transaction ID from send_coins method
        transaction_id = getattr(self, 'last_transaction_id', None)
        print(f"{current_time} Transaction #{transaction_id}: id={transaction_id}, status=confirmed, "
                  f"timestamp=\"20231110 13:05:00.101\", coin=1.0, source={self.public_key}, "
                  f"destination=HtBTNpCt5fmPrvESqVp1UFsiX5wnMCtmgt7Cxi85MFiF")
        print(f"{current_time} The above response is just a placeholder, since the blockchain and pool server "
                  f"has not yet been implemented fully, \n No transactions found for the given public key.")


def log_message(message):
    current_time = datetime.datetime.now().strftime('%Y%m%d %H:%M:%S.%f')[:-3]
    print(f"{current_time} {message}")


def main():
    if len(sys.argv) < 3:
        print("Usage: ./dsc wallet <command>")
        sys.exit(1)

    command = sys.argv[2]
    wallet = DSCWallet()
    blockchain = Blockchain()
    pool = Pool()
    metronome = Metronome(blockchain)


    if command == "help":
        print("DSC: DataSys Coin Blockchain v1.0")
        print("Help menu, supported commands:")
        print("./dsc help")
        print("./dsc wallet")
        print("./dsc blockchain")
        print("./dsc pool key")
        print("./dsc metronome")
        print("./dsc validator")
        print("./dsc monitor")


    elif command == "pool":

        if len(sys.argv) != 4:
            print("Usage: ./dsc pool <num_threads>")

            sys.exit(1)

        num_threads = int(sys.argv[3])

        pool.start_pool(num_threads)

    elif command == "metronome":

        if len(sys.argv) != 4:
            print("Usage: ./dsc metronome <num_threads>")

            sys.exit(1)

        num_threads = int(sys.argv[3])

        metronome.start_metronome(num_threads)


    elif command == "blockchain":

        print(f"{datetime.datetime.now().strftime('%Y%m%d %H:%M:%S.%f')[:-3]} DSC v1.0")

        print(f"{datetime.datetime.now().strftime('%Y%m%d %H:%M:%S.%f')[:-3]} BlockChain server started with 2 threads")

        #the validator fingerprint is hard-coded for demonstration purposes

        validator_fingerprint = "e6a75580-a7d3-4bee-9d21-f289a45bd36b"

        for i in range(1, 5):  # Process block requests for blocks 1 to 4

            blockchain.process_block_request(validator_fingerprint, i)

        # Sample balance and transaction requests

        blockchain.process_balance_request("8cxiskBh2AJSNefWKPQ7ErfmLoM4hs4esGq8REu63C3U")

        blockchain.process_balance_request("HtBTNpCt5fmPrvESqVp1UFsiX5wnMCtmgt7Cxi85MFiF")

        blockchain.process_transaction_request(validator_fingerprint, "0xEksacU61zEbu5kP6WBTW48")

        blockchain.process_transactions_request("8cxiskBh2AJSNefWKPQ7ErfmLoM4hs4esGq8REu63C3U")


    elif command == "wallet":
        wallet_command = sys.argv[3] if len(sys.argv) > 3 else None

        if wallet_command == "help":
            print("DSC: DataSys Coin Blockchain v1.0")
            print("Help menu for Wallet, supported commands:")
            print("./dsc wallet help")
            print("./dsc wallet create")
            print("./dsc wallet key")
            print("./dsc wallet balance")
            print("./dsc wallet send <amount> <address>")
            print("./dsc wallet transaction <ID>")

        elif wallet_command == "create":
            wallet.create_wallet()
        elif wallet_command == "key":
            wallet.read_key()
        elif wallet_command == "balance":
            wallet.get_balance()
        elif wallet_command == "validator":
            print("task for next checkpoint")
        elif wallet_command == "monitor":
            print("task for next checkpoint")
        elif wallet_command == "send":
            if len(sys.argv) != 6:
                print("Usage: ./dsc wallet send <amount> <destination_address>")
                sys.exit(1)

            amount = sys.argv[4]
            destination_address = sys.argv[5]

            wallet.send_coins(amount, destination_address)
        elif wallet_command == "transaction":
            wallet.get_all_transactions()
        else:
            print("Invalid wallet command. Use './dsc wallet help' for a list of supported commands.")
    else:
        print("Invalid command. Use './dsc help' for a list of supported commands.")

if __name__ == "__main__":
    main()
