import socket
import threading
import jsonpickle
import time
from datetime import datetime

class MetronomeClient:
    def __init__(self, server_host, server_port):
        self.server_host = server_host
        self.server_port = server_port
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def connect(self):
        try:
            self.client_socket.connect((self.server_host, self.server_port))
            print(f"Connected to blockchain server at {self.server_host}:{self.server_port}")
        except Exception as e:
            print(f"Error connecting to server: {e}")

    def send_metronome_data(self):
        data = {'action': 'metronome'}

        try:
            message = jsonpickle.encode(data)
            self.client_socket.sendall(message.encode())
            response = self.client_socket.recv(1024).decode()
            print(f"Server response: {response}")
        except Exception as e:
            print(f"Error sending metronome data: {e}")

    def close_connection(self):
        self.client_socket.close()
        print("Connection closed")


if __name__ == "__main__":
    server_host = "localhost"
    server_port = 6000

    metronome_client = MetronomeClient(server_host, server_port)
    metronome_client.connect()

    try:
        while True:
            metronome_client.send_metronome_data()
    except KeyboardInterrupt:
        pass
    finally:
        metronome_client.close_connection()
