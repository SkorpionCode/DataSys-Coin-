from block import Block
from random import randint
from transaction import Transaction
import hashlib
import time
import requests
import jsonpickle
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization
import base58
import yaml
import uuid  # for generating transaction ID
from cryptography.hazmat.primitives import hashes  # Import for signature hashing

class Blockchain:
    def __init__(self, node_id, init_txs=None, host=None, boot_node=None):
        self.node_id = node_id
        self.mempool = []
        self.host = host if host else f'localhost:{randint(3000, 9000)}'
        self.blocks = [Block(0, "genesis_block", 0, "0", init_txs if init_txs else [])]
        self.peerstore = set()
        self.peerstore.add(self.host)
        if boot_node:
            self.add_peer(boot_node)

    def new_transaction(self, sender, to, amount, wallet=None):
        if wallet:
            balance = wallet.get_balance()
            if amount > balance:
                raise Exception("not enough balance", amount, balance)
            tx = wallet.create_transaction(to, amount)
        else:
            balance = self.get_balance(sender)
            if amount > balance:
                raise Exception("not enough balance", amount, balance)
            tx = Transaction(sender, to, amount)

        self.mempool.append(tx)
        return tx

    def get_balance(self, account):
        balance = 0
        for block in self.blocks:
            for tx in block.txs:
                if tx.sender == account:
                    balance -= tx.amount
                elif tx.to == account:
                    balance += tx.amount
        return balance

    def gossip_peerstore(self):
        for peer in self.peerstore.copy():
            for peer_info in self.peerstore.copy():
                if peer != peer_info and peer != self.host:
                    url = f'http://{peer}/addpeer?peer={peer_info}'
                    try:
                        requests.get(url)
                    except Exception as e:
                        # TODO: Prune erroring peers
                        print("Error", e)

    def resolve_split(self):
        for peer in self.peerstore:
            if peer == self.host:
                continue
            url = f'http://{peer}/getblockchain'
            try:
                blockchain = requests.get(url)
                blocks = jsonpickle.decode(blockchain.text)

                # Use always the longest chain
                if len(blocks) > len(self.blocks):
                    # TODO: Check that the blocks are valid
                    self.blocks = blocks
            except Exception as e:
                print("Error", e)

    def add_peer(self, peer_host):
        self.peerstore.add(peer_host)

    def mine(self):
        proof = 0
        while not self.is_valid_proof(self.blocks[-1], proof):
            proof = randint(0, 100000)
            time.sleep(0.05)

        # once the proof is found, create a new block with txs in the pool
        new_index = self.blocks[-1].index + 1
        block = Block(new_index, self.node_id, proof, self.blocks[-1].hash, self.mempool)

        # add a reward for the miner
        block.txs.append(Transaction('0', self.node_id, 50))

        self.add_block(block)
        self.mempool = []

        print("New block", block)

        # broadcast block
        self.broadcast_block(block)

        return block

    def add_block(self, block):
        # TODO run more checks
        # TODO handle blocks out of order
        if self.blocks[-1].hash == block.prev_hash:
            self.blocks.append(block)

    def broadcast_block(self, block):
        for peer in self.peerstore:
            if peer == self.host:
                continue
            url = f'http://{peer}/addblock?block={jsonpickle.encode(block)}'
            try:
                requests.get(url)
            except Exception as e:
                print("Error", e)

    def is_valid_proof(self, last_block, proof):
        guess = f'{last_block.proof}{proof}{last_block.hash}'.encode()
        guess_hash = hashlib.sha256(guess).hexdigest()
        # TODO: Set variable difficulty
        return guess_hash[:2] == "00"

class Wallet:
    def __init__(self, blockchain, wallet_id):
        self.blockchain = blockchain
        self.wallet_id = wallet_id
        self.private_key, self.public_key = self.load_or_generate_keys()

    def generate_key_pair(self):
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
            backend=default_backend()
        )
        public_key = private_key.public_key()

        return private_key, public_key

    def load_or_generate_keys(self):
        try:
            with open(f'dsc-key-{self.wallet_id}.yaml', 'r') as key_file:
                key_data = yaml.safe_load(key_file)
                private_key = serialization.load_pem_private_key(
                    key_data['private_key'].encode(),
                    password=None,
                    backend=default_backend()
                )
                public_key = serialization.load_pem_public_key(
                    key_data['public_key'].encode(),
                    backend=default_backend()
                )
        except (FileNotFoundError, yaml.YAMLError):
            private_key, public_key = self.generate_key_pair()
            self.save_keys(private_key, public_key)

        return private_key, public_key

    def save_keys(self, private_key, public_key):
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )

        key_data = {
            'private_key': private_pem.decode(),
            'public_key': public_pem.decode()
        }

        with open(f'dsc-key-{self.wallet_id}.yaml', 'w') as key_file:
            yaml.dump(key_data, key_file)

    def get_balance(self):
        return self.blockchain.get_balance(self.wallet_id)

    def create_and_send_transaction(self, to, amount):
        transaction_id = str(uuid.uuid4())[:16]  # Generate a unique transaction ID

        # Create a new transaction with the generated transaction ID
        transaction = Transaction(
            sender=self.wallet_id,
            to=to,
            amount=amount,
            transaction_id=transaction_id
        )

        # Send the transaction to a pool server (simulated here as a localhost endpoint)
        pool_server_url = "http://localhost:8000/receive_transaction"
        data = {
            'transaction_id': transaction_id,
            'transaction_data': transaction.__dict__
        }

        try:
            response = requests.post(pool_server_url, json=data)
            if response.status_code == 200:
                print(f"Transaction {transaction_id} sent successfully.")
                return transaction_id
            else:
                print(f"Failed to send transaction {transaction_id}. Server response: {response.text}")
                return None
        except Exception as e:
            print(f"Error sending transaction {transaction_id}: {e}")
            return None

    def create_transaction(self, to, amount):
        if amount > self.get_balance():
            raise Exception("not enough balance", amount, self.get_balance())

        # Sign the transaction with the private key
        signature = self.private_key.sign(
            f"{self.wallet_id}{to}{amount}".encode(),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )

        return Transaction(self.wallet_id, to, amount, signature)

