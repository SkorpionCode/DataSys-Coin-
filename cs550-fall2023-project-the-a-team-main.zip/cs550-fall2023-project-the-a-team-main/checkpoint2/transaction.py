import jsonpickle
import time

class Transaction:
    def __init__(self, sender, to, amount, transaction_id=None, signature=None):
        self.sender = sender
        self.to = to
        self.amount = amount
        self.timestamp = time.strftime("%m/%d/%Y, %H:%M:%S")
        self.transaction_id = transaction_id

    def __str__(self):
        return jsonpickle.encode(self)

    def __repr__(self):
        return str(self)