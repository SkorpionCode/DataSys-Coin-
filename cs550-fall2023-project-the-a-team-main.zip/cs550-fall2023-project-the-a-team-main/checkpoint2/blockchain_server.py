import socket
import threading
import jsonpickle
import time
from block import Block
from transaction import Transaction
from blockchain import Blockchain, Wallet

class BlockchainServer:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.blockchain = Blockchain(node_id=f"{host}:{port}", init_txs=[], host=host)
        self.wallet = Wallet(self.blockchain, wallet_id=f"User-{port}")

    def start(self):
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen()

        print(f"Blockchain server listening on {self.host}:{self.port}")

        while True:
            client_socket, client_address = self.server_socket.accept()
            client_thread = threading.Thread(target=self.handle_client, args=(client_socket, client_address))
            client_thread.start()

    def handle_client(self, client_socket, client_address):
        print(f"Accepted connection from {client_address}")

        while True:
            try:
                data = client_socket.recv(1024)
                if not data:
                    break

                decoded_data = data.decode()
                response = self.process_data(decoded_data)

                client_socket.sendall(response.encode())
            except Exception as e:
                print(f"Error handling client: {e}")
                break

        print(f"Connection from {client_address} closed")
        client_socket.close()

    def start_metronome(self):
        interval = 6  # Set the interval to 6 seconds
        while True:
            time.sleep(interval)
            block = self.blockchain.mine()
            timestamp = datetime.now().strftime("%Y%m%d %H:%M:%S.%f")[:-3]
            print(f"{timestamp} New block created, hash {block.hash}, sent to blockchain")

    def process_data(self, data):
        try:
            # Assuming data is a JSON-encoded string
            data_dict = jsonpickle.decode(data)

            if 'action' in data_dict:
                action = data_dict['action']

                if action == 'new_transaction':
                    sender = data_dict['sender']
                    to = data_dict['to']
                    amount = data_dict['amount']

                    transaction = self.wallet.new_transaction(sender, to, amount)
                    return jsonpickle.encode({'status': 'success', 'transaction': transaction.__dict__})

                elif action == 'get_balance':
                    account = data_dict['account']
                    balance = self.blockchain.get_balance(account)
                    return jsonpickle.encode({'status': 'success', 'balance': balance})

                elif action == 'mine':
                    block = self.blockchain.mine()
                    return jsonpickle.encode({'status': 'success', 'block': block.__dict__})


                elif action == 'metronome':

                    print("Metronome connected")

                    self.start_metronome()

                    return jsonpickle.encode({'status': 'success', 'message': 'Metronome connected'})


                else:

                    return jsonpickle.encode({'status': 'error', 'message': 'Invalid action'})

            else:
                return jsonpickle.encode({'status': 'error', 'message': 'No action specified'})

        except Exception as e:
            return jsonpickle.encode({'status': 'error', 'message': str(e)})

if __name__ == "__main__":
    server_host = "localhost"
    server_port = 6000

    blockchain_server = BlockchainServer(server_host, server_port)
    blockchain_server.start()


