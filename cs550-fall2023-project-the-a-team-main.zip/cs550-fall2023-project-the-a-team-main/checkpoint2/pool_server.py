from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from collections import deque

class PoolServer(BaseHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        # Using deque for O(1) insertion and removal at both ends
        self.submitted_transactions = deque()
        self.unconfirmed_transactions = {}
        super().__init__(*args, **kwargs)

    def _send_response(self, code, message):
        self.send_response(code)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(message).encode('utf-8'))

    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        data = json.loads(post_data.decode('utf-8'))

        if 'transaction_id' in data and 'transaction_data' in data:
            transaction_id = data['transaction_id']
            transaction_data = data['transaction_data']

            # Add to both submitted and unconfirmed transactions
            self.submitted_transactions.append((transaction_id, transaction_data))
            self.unconfirmed_transactions[transaction_id] = transaction_data

            response_message = {'message': 'Transaction received successfully'}
            self._send_response(200, response_message)
        elif 'validator_request' in data:
            # Validator requests a transaction
            requested_transaction = self.request_transaction()

            if requested_transaction:
                self._send_response(200, requested_transaction)
            else:
                response_message = {'error': 'No transactions available'}
                self._send_response(404, response_message)
        elif 'confirm_block' in data:
            # Confirm a block and remove transactions from unconfirmed pile
            self.confirm_block()
            response_message = {'message': 'Block confirmed'}
            self._send_response(200, response_message)
        else:
            response_message = {'error': 'Invalid request'}
            self._send_response(400, response_message)

    def request_transaction(self):
        if not self.submitted_transactions:
            return None

        # Remove from submitted and add to unconfirmed
        transaction_id, transaction_data = self.submitted_transactions.popleft()
        del self.unconfirmed_transactions[transaction_id]

        response_message = {'transaction_id': transaction_id, 'transaction_data': transaction_data}
        return response_message

    def confirm_block(self):
        # Clear all transactions from the unconfirmed pile (block confirmed)
        self.unconfirmed_transactions.clear()

def run(server_class=HTTPServer, handler_class=PoolServer, port=8000):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f'Starting pool server on port {port}...')
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
        print('Pool server stopped.')

if __name__ == '__main__':
    run()
